export interface PostFolderDto {
  name: string;
  parentFolderId: string;
}
