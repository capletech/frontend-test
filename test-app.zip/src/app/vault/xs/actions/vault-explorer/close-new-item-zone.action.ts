export class CloseNewItemZone {
  static readonly type = '[Vault Explorer] Close New Item Zone';
}
