export class OpenNewItemZone {
  static readonly type = '[Vault Explorer] Open New Item Zone';

  constructor(public readonly folderId: string) {}
}
