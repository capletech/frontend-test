export class ClearVaultState   {
  static readonly type = '[Vault] Clear Vault State';
}
