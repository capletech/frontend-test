export class InitVaultTree {
  static readonly type = '[Vault] Init tree';
}
